#!/bin/bash
sudo bin/containerd
