#!/bin/bash
bin/cilium install

# kubectl apply -f service.yaml

# try this
# kubectl expose deployment web --port=80
# kubectl get svc
