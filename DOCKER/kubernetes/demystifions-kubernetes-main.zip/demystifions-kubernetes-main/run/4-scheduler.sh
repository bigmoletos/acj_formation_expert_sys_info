#!/bin/bash
bin/kube-scheduler --kubeconfig admin.conf
